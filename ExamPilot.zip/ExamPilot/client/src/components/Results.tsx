import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle, Trophy, Clock, Award } from "lucide-react";
import { Exam, UserAnswer } from "@shared/schema";

interface ResultsProps {
  exam: Exam;
  answers: UserAnswer[];
  score: number;
  timeSpent: number;
  onBackToDashboard: () => void;
  onViewLeaderboard: () => void;
}

export default function Results({ 
  exam, 
  answers, 
  score, 
  timeSpent, 
  onBackToDashboard,
  onViewLeaderboard 
}: ResultsProps) {
  const percentage = (score / exam.questions.length) * 100;
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  const getGrade = (percentage: number) => {
    if (percentage >= 90) return { grade: "A+", color: "bg-success text-success-foreground" };
    if (percentage >= 80) return { grade: "A", color: "bg-success text-success-foreground" };
    if (percentage >= 70) return { grade: "B", color: "bg-primary text-primary-foreground" };
    if (percentage >= 60) return { grade: "C", color: "bg-primary text-primary-foreground" };
    if (percentage >= 50) return { grade: "D", color: "bg-destructive text-destructive-foreground" };
    return { grade: "F", color: "bg-destructive text-destructive-foreground" };
  };

  const { grade, color } = getGrade(percentage);

  return (
    <div className="min-h-screen p-4 bg-gradient-to-br from-primary/5 via-background to-success/5">
      <div className="container mx-auto max-w-4xl py-12">
        <div className="text-center mb-10">
          <div className="inline-block p-3 bg-primary/10 rounded-full mb-4">
            <Trophy className="h-10 w-10 text-primary" />
          </div>
          <h1 className="text-4xl font-serif font-bold mb-3">Test Completed!</h1>
          <p className="text-lg text-muted-foreground">{exam.title}</p>
        </div>

        <Card className="mb-8 shadow-lg">
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-2xl">Your Score</CardTitle>
          </CardHeader>
          <CardContent className="space-y-8">
            <div className="text-center">
              <div className="text-7xl font-bold text-primary mb-3" data-testid="text-score">
                {percentage.toFixed(1)}%
              </div>
              <div className="flex items-center justify-center gap-4 text-base text-muted-foreground">
                <span data-testid="text-correct">{score} correct</span>
                <span>•</span>
                <span>{exam.questions.length - score} incorrect</span>
              </div>
              <Badge className={`mt-6 px-6 py-2 text-lg ${color}`} data-testid="badge-grade">{grade}</Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-4 flex items-center gap-3">
                  <Trophy className="h-8 w-8 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Score</p>
                    <p className="text-xl font-semibold">{score}/{exam.questions.length}</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 flex items-center gap-3">
                  <Clock className="h-8 w-8 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Time Taken</p>
                    <p className="text-xl font-semibold" data-testid="text-time-spent">{formatTime(timeSpent)}</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 flex items-center gap-3">
                  <Award className="h-8 w-8 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Accuracy</p>
                    <p className="text-xl font-semibold">{percentage.toFixed(0)}%</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Answer Review</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {exam.questions.map((question, index) => {
                const userAnswer = answers[index];
                const isCorrect = userAnswer?.selectedAnswer === question.correctAnswer;
                
                return (
                  <div
                    key={question.id}
                    className="p-4 border rounded-md"
                    data-testid={`review-question-${index + 1}`}
                  >
                    <div className="flex items-start gap-3">
                      {isCorrect ? (
                        <CheckCircle2 className="h-5 w-5 text-success flex-shrink-0 mt-0.5" />
                      ) : (
                        <XCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
                      )}
                      <div className="flex-1">
                        <p className="font-medium mb-2">
                          Question {index + 1}: {question.text}
                        </p>
                        <div className="space-y-1 text-sm">
                          <p className={isCorrect ? "text-success" : "text-destructive"}>
                            Your answer: {userAnswer?.selectedAnswer !== null && userAnswer?.selectedAnswer !== undefined
                              ? question.options[userAnswer.selectedAnswer]
                              : "Not answered"}
                          </p>
                          {!isCorrect && (
                            <p className="text-success">
                              Correct answer: {question.options[question.correctAnswer]}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <div className="flex items-center justify-center gap-4">
          <Button variant="outline" onClick={onBackToDashboard} data-testid="button-dashboard">
            Back to Dashboard
          </Button>
          <Button onClick={onViewLeaderboard} data-testid="button-view-leaderboard">
            View Leaderboard
          </Button>
        </div>
      </div>
    </div>
  );
}

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UserAnswer } from "@shared/schema";

interface QuestionPaletteProps {
  totalQuestions: number;
  currentQuestion: number;
  answers: UserAnswer[];
  onQuestionSelect: (index: number) => void;
}

export default function QuestionPalette({ 
  totalQuestions, 
  currentQuestion, 
  answers, 
  onQuestionSelect 
}: QuestionPaletteProps) {
  const getQuestionStatus = (index: number) => {
    const answer = answers[index];
    if (index === currentQuestion) return "current";
    if (answer?.selectedAnswer !== null && answer?.selectedAnswer !== undefined) return "answered";
    return "unanswered";
  };

  const getButtonVariant = (status: string) => {
    switch (status) {
      case "current":
        return "default";
      case "answered":
        return "secondary";
      default:
        return "outline";
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Question Palette</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-5 gap-2">
          {Array.from({ length: totalQuestions }, (_, i) => {
            const status = getQuestionStatus(i);
            return (
              <Button
                key={i}
                variant={getButtonVariant(status)}
                size="sm"
                className="w-full"
                onClick={() => onQuestionSelect(i)}
                data-testid={`button-question-${i + 1}`}
              >
                {i + 1}
              </Button>
            );
          })}
        </div>
        <div className="mt-4 space-y-2 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-primary rounded" />
            <span className="text-muted-foreground">Current</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-secondary rounded" />
            <span className="text-muted-foreground">Answered</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 border border-input rounded" />
            <span className="text-muted-foreground">Not Answered</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

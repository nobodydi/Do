import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Clock, ChevronLeft, ChevronRight } from "lucide-react";
import { Exam, UserAnswer, User } from "@shared/schema";
import QuestionPalette from "./QuestionPalette";
import { useToast } from "@/hooks/use-toast";

interface ExamInterfaceProps {
  exam: Exam;
  user: User;
  onComplete: (answers: UserAnswer[], timeSpent: number) => void;
  onExit: () => void;
}

export default function ExamInterface({ exam, user, onComplete, onExit }: ExamInterfaceProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<UserAnswer[]>(
    exam.questions.map(q => ({ questionId: q.id, selectedAnswer: null }))
  );
  const [timeLeft, setTimeLeft] = useState(exam.duration * 60);
  const { toast } = useToast();

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const currentQuestion = exam.questions[currentQuestionIndex];
  const currentAnswer = answers[currentQuestionIndex];

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleAnswerSelect = (value: string) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestionIndex] = {
      questionId: currentQuestion.id,
      selectedAnswer: parseInt(value),
    };
    setAnswers(newAnswers);
  };

  const handleSubmit = () => {
    const timeSpent = exam.duration * 60 - timeLeft;
    onComplete(answers, timeSpent);
  };

  const handleNext = () => {
    if (currentQuestionIndex < exam.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const answeredCount = answers.filter(a => a.selectedAnswer !== null).length;
  const isTimeCritical = timeLeft < 300;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card sticky top-0 z-10 shadow-sm">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-serif font-bold">{exam.title}</h1>
            <p className="text-sm text-muted-foreground">
              Question {currentQuestionIndex + 1} of {exam.questions.length}
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className={`flex items-center gap-2 px-4 py-2 rounded-md font-mono text-lg font-semibold ${isTimeCritical ? 'text-destructive bg-destructive/10' : 'text-foreground bg-muted'}`}>
              <Clock className="h-5 w-5" />
              <span data-testid="text-timer">{formatTime(timeLeft)}</span>
            </div>
            <Button variant="outline" onClick={onExit} data-testid="button-exit">
              Exit
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card className="shadow-sm">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg font-semibold">
                  Question {currentQuestionIndex + 1}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-lg leading-relaxed" data-testid={`text-question-${currentQuestionIndex + 1}`}>
                  {currentQuestion.text}
                </p>

                <RadioGroup
                  value={currentAnswer?.selectedAnswer?.toString() ?? ""}
                  onValueChange={handleAnswerSelect}
                  className="space-y-3"
                >
                  {currentQuestion.options.map((option, index) => (
                    <div
                      key={index}
                      className="flex items-center space-x-3 p-4 rounded-md hover-elevate border transition-all"
                    >
                      <RadioGroupItem
                        value={index.toString()}
                        id={`option-${index}`}
                        data-testid={`radio-option-${index}`}
                      />
                      <Label
                        htmlFor={`option-${index}`}
                        className="flex-1 cursor-pointer text-base"
                      >
                        {option}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </CardContent>
            </Card>

            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={currentQuestionIndex === 0}
                data-testid="button-previous"
              >
                <ChevronLeft className="h-4 w-4 mr-2" />
                Previous
              </Button>

              <div className="text-sm text-muted-foreground">
                Answered: {answeredCount} / {exam.questions.length}
              </div>

              {currentQuestionIndex === exam.questions.length - 1 ? (
                <Button onClick={handleSubmit} data-testid="button-submit" className="bg-success hover:bg-success border-success-border">
                  Submit Test
                </Button>
              ) : (
                <Button onClick={handleNext} data-testid="button-next">
                  Next
                  <ChevronRight className="h-4 w-4 ml-2" />
                </Button>
              )}
            </div>
          </div>

          <div>
            <QuestionPalette
              totalQuestions={exam.questions.length}
              currentQuestion={currentQuestionIndex}
              answers={answers}
              onQuestionSelect={setCurrentQuestionIndex}
            />
          </div>
        </div>
      </main>
    </div>
  );
}

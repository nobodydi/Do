import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Trophy, Medal, Award, ArrowLeft } from "lucide-react";
import { ExamAttempt } from "@shared/schema";

interface LeaderboardProps {
  attempts: ExamAttempt[];
  currentUserId: string;
  onBack: () => void;
}

export default function Leaderboard({ attempts, currentUserId, onBack }: LeaderboardProps) {
  const sortedAttempts = [...attempts].sort((a, b) => b.score - a.score);
  const topThree = sortedAttempts.slice(0, 3);
  const rest = sortedAttempts.slice(3);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-6 w-6 text-yellow-500" />;
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />;
      case 3:
        return <Award className="h-6 w-6 text-amber-600" />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen p-4">
      <div className="container mx-auto max-w-4xl py-8">
        <div className="mb-6">
          <Button variant="ghost" onClick={onBack} data-testid="button-back">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
        </div>

        <div className="text-center mb-8">
          <h1 className="text-3xl font-serif font-bold mb-2">Leaderboard</h1>
          <p className="text-muted-foreground">Top performers across all exams</p>
        </div>

        {topThree.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            {topThree.map((attempt, index) => {
              const percentage = (attempt.score / attempt.totalQuestions) * 100;
              const isCurrentUser = attempt.userId === currentUserId;
              
              return (
                <Card
                  key={attempt.id}
                  className={`${isCurrentUser ? "border-primary" : ""}`}
                  data-testid={`card-top-${index + 1}`}
                >
                  <CardContent className="p-6 text-center">
                    <div className="flex justify-center mb-3">
                      {getRankIcon(index + 1)}
                    </div>
                    <h3 className="font-semibold text-lg mb-1" data-testid={`text-username-${index + 1}`}>
                      {attempt.username}
                      {isCurrentUser && (
                        <Badge variant="secondary" className="ml-2">You</Badge>
                      )}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-2">{attempt.examTitle}</p>
                    <p className="text-2xl font-bold text-primary" data-testid={`text-score-${index + 1}`}>
                      {percentage.toFixed(0)}%
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {attempt.score}/{attempt.totalQuestions}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {rest.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>All Rankings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {rest.map((attempt, index) => {
                  const rank = index + 4;
                  const percentage = (attempt.score / attempt.totalQuestions) * 100;
                  const isCurrentUser = attempt.userId === currentUserId;

                  return (
                    <div
                      key={attempt.id}
                      className={`flex items-center justify-between p-3 rounded-md border ${
                        isCurrentUser ? "border-primary bg-primary/5" : ""
                      }`}
                      data-testid={`row-rank-${rank}`}
                    >
                      <div className="flex items-center gap-4">
                        <span className="font-semibold text-muted-foreground w-8">#{rank}</span>
                        <div>
                          <p className="font-medium">
                            {attempt.username}
                            {isCurrentUser && (
                              <Badge variant="secondary" className="ml-2">You</Badge>
                            )}
                          </p>
                          <p className="text-sm text-muted-foreground">{attempt.examTitle}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">{percentage.toFixed(0)}%</p>
                        <p className="text-sm text-muted-foreground">
                          {attempt.score}/{attempt.totalQuestions}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {attempts.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <Trophy className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-lg text-muted-foreground">
                No attempts yet. Complete a test to appear on the leaderboard!
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { LogOut, User as UserIcon, Trophy, BarChart } from "lucide-react";
import ExamCard from "./ExamCard";
import { mockExams } from "@/lib/examData";

interface DashboardProps {
  user: User;
  onLogout: () => void;
  onStartExam: (examId: string) => void;
  onViewProfile: () => void;
  onViewLeaderboard: () => void;
}

export default function Dashboard({ user, onLogout, onStartExam, onViewProfile, onViewLeaderboard }: DashboardProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-success/5">
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-6 py-5 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-serif font-bold text-primary">MockTest Pro</h1>
            <p className="text-sm text-muted-foreground">Welcome, {user.username}</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" onClick={onViewProfile} data-testid="button-profile">
              <UserIcon className="h-4 w-4 mr-2" />
              Profile
            </Button>
            <Button variant="ghost" onClick={onViewLeaderboard} data-testid="button-leaderboard">
              <Trophy className="h-4 w-4 mr-2" />
              Leaderboard
            </Button>
            <Button variant="outline" onClick={onLogout} data-testid="button-logout">
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-12">
        <div className="mb-10 text-center">
          <h2 className="text-4xl font-serif font-bold mb-3">Available Exams</h2>
          <p className="text-lg text-muted-foreground">Choose an exam to begin your practice</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
          {mockExams.map((exam) => (
            <ExamCard key={exam.id} exam={exam} onStart={onStartExam} />
          ))}
        </div>
      </main>
    </div>
  );
}

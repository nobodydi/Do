import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, FileText, TrendingUp } from "lucide-react";
import { Exam } from "@shared/schema";

interface ExamCardProps {
  exam: Exam;
  onStart: (examId: string) => void;
}

export default function ExamCard({ exam, onStart }: ExamCardProps) {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy":
        return "bg-success text-success-foreground";
      case "Medium":
        return "bg-primary text-primary-foreground";
      case "Hard":
        return "bg-destructive text-destructive-foreground";
      default:
        return "bg-secondary text-secondary-foreground";
    }
  };

  return (
    <Card className="hover-elevate transition-all duration-200 group" data-testid={`card-exam-${exam.id}`}>
      <CardHeader className="gap-3 space-y-0 pb-5">
        <div className="flex items-start justify-between gap-3">
          <CardTitle className="text-xl font-serif font-semibold group-hover:text-primary transition-colors">{exam.title}</CardTitle>
          <Badge className={`${getDifficultyColor(exam.difficulty)} font-medium`} data-testid={`badge-difficulty-${exam.id}`}>
            {exam.difficulty}
          </Badge>
        </div>
        <CardDescription className="text-sm leading-relaxed">{exam.description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="flex items-center flex-wrap gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <Clock className="h-4 w-4" />
            <span data-testid={`text-duration-${exam.id}`}>{exam.duration} mins</span>
          </div>
          <div className="flex items-center gap-1.5">
            <FileText className="h-4 w-4" />
            <span data-testid={`text-questions-${exam.id}`}>{exam.totalQuestions} questions</span>
          </div>
          <div className="flex items-center gap-1.5">
            <TrendingUp className="h-4 w-4" />
            <span>{exam.subjects.join(", ")}</span>
          </div>
        </div>
        <Button 
          className="w-full h-11 font-medium" 
          onClick={() => onStart(exam.id)}
          data-testid={`button-start-${exam.id}`}
        >
          Start Test
        </Button>
      </CardContent>
    </Card>
  );
}

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Calendar, Trophy, Target } from "lucide-react";
import { User, ExamAttempt } from "@shared/schema";

interface ProfileProps {
  user: User;
  attempts: ExamAttempt[];
  onBack: () => void;
}

export default function Profile({ user, attempts, onBack }: ProfileProps) {
  const userAttempts = attempts.filter(a => a.userId === user.id);
  const totalTests = userAttempts.length;
  const averageScore = totalTests > 0
    ? userAttempts.reduce((sum, a) => sum + (a.score / a.totalQuestions) * 100, 0) / totalTests
    : 0;
  const bestScore = totalTests > 0
    ? Math.max(...userAttempts.map(a => (a.score / a.totalQuestions) * 100))
    : 0;

  return (
    <div className="min-h-screen p-4">
      <div className="container mx-auto max-w-4xl py-8">
        <div className="mb-6">
          <Button variant="ghost" onClick={onBack} data-testid="button-back">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>

        <div className="mb-8">
          <h1 className="text-3xl font-serif font-bold mb-2">My Profile</h1>
          <p className="text-muted-foreground">{user.email}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <Target className="h-8 w-8 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Tests Taken</p>
                  <p className="text-2xl font-bold" data-testid="text-total-tests">{totalTests}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <Trophy className="h-8 w-8 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Average Score</p>
                  <p className="text-2xl font-bold" data-testid="text-avg-score">{averageScore.toFixed(0)}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <Trophy className="h-8 w-8 text-success" />
                <div>
                  <p className="text-sm text-muted-foreground">Best Score</p>
                  <p className="text-2xl font-bold" data-testid="text-best-score">{bestScore.toFixed(0)}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Test History</CardTitle>
          </CardHeader>
          <CardContent>
            {userAttempts.length > 0 ? (
              <div className="space-y-3">
                {userAttempts.map((attempt) => {
                  const percentage = (attempt.score / attempt.totalQuestions) * 100;
                  const date = new Date(attempt.completedAt).toLocaleDateString();
                  
                  return (
                    <div
                      key={attempt.id}
                      className="flex items-center justify-between p-4 border rounded-md"
                      data-testid={`history-item-${attempt.id}`}
                    >
                      <div className="flex-1">
                        <h4 className="font-medium">{attempt.examTitle}</h4>
                        <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            <span>{date}</span>
                          </div>
                          <span>
                            {Math.floor(attempt.timeSpent / 60)}m {attempt.timeSpent % 60}s
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge
                          className={
                            percentage >= 80
                              ? "bg-success text-success-foreground"
                              : percentage >= 60
                              ? "bg-primary text-primary-foreground"
                              : "bg-destructive text-destructive-foreground"
                          }
                        >
                          {percentage.toFixed(0)}%
                        </Badge>
                        <p className="text-sm text-muted-foreground mt-1">
                          {attempt.score}/{attempt.totalQuestions}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <Target className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">
                  No tests taken yet. Start a test to build your history!
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

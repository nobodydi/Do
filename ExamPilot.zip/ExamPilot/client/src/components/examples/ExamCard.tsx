import ExamCard from '../ExamCard';

export default function ExamCardExample() {
  const mockExam = {
    id: "demo-exam",
    title: "NEET Physics Mock Test 1",
    description: "Comprehensive physics test covering mechanics, thermodynamics, and modern physics",
    duration: 45,
    totalQuestions: 20,
    difficulty: "Medium" as const,
    subjects: ["Physics"],
    questions: []
  };

  return (
    <div className="p-4 max-w-md">
      <ExamCard 
        exam={mockExam}
        onStart={(id) => console.log('Start exam:', id)}
      />
    </div>
  );
}

import Profile from '../Profile';

export default function ProfileExample() {
  const mockUser = {
    id: "current-user",
    username: "johndoe",
    email: "john@example.com",
    password: "",
    createdAt: new Date().toISOString()
  };

  const mockAttempts = [
    {
      id: "1",
      examId: "exam1",
      examTitle: "NEET Physics Mock Test 1",
      userId: "current-user",
      username: "johndoe",
      answers: [],
      score: 18,
      totalQuestions: 20,
      timeSpent: 2400,
      completedAt: new Date(Date.now() - 86400000).toISOString()
    },
    {
      id: "2",
      examId: "exam2",
      examTitle: "NEET Chemistry Mock Test 1",
      userId: "current-user",
      username: "johndoe",
      answers: [],
      score: 16,
      totalQuestions: 20,
      timeSpent: 2500,
      completedAt: new Date(Date.now() - 172800000).toISOString()
    },
    {
      id: "3",
      examId: "exam3",
      examTitle: "JEE Mathematics Mock Test 1",
      userId: "current-user",
      username: "johndoe",
      answers: [],
      score: 22,
      totalQuestions: 30,
      timeSpent: 3200,
      completedAt: new Date(Date.now() - 259200000).toISOString()
    }
  ];

  return (
    <Profile 
      user={mockUser}
      attempts={mockAttempts}
      onBack={() => console.log('Back to dashboard')}
    />
  );
}

import Dashboard from '../Dashboard';

export default function DashboardExample() {
  const mockUser = {
    id: "1",
    username: "johndoe",
    email: "john@example.com",
    password: "",
    createdAt: new Date().toISOString()
  };

  return (
    <Dashboard 
      user={mockUser}
      onLogout={() => console.log('Logout')}
      onStartExam={(id) => console.log('Start exam:', id)}
      onViewProfile={() => console.log('View profile')}
      onViewLeaderboard={() => console.log('View leaderboard')}
    />
  );
}

import Signup from '../Signup';

export default function SignupExample() {
  return (
    <Signup 
      onSignup={(user) => console.log('Signup successful:', user)}
      onSwitchToLogin={() => console.log('Switch to login')}
    />
  );
}

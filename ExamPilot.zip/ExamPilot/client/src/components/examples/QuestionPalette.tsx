import { useState } from 'react';
import QuestionPalette from '../QuestionPalette';

export default function QuestionPaletteExample() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  
  const mockAnswers = [
    { questionId: "q1", selectedAnswer: 1 },
    { questionId: "q2", selectedAnswer: 0 },
    { questionId: "q3", selectedAnswer: null },
    { questionId: "q4", selectedAnswer: 2 },
    { questionId: "q5", selectedAnswer: null },
  ];

  return (
    <div className="p-4 max-w-md">
      <QuestionPalette
        totalQuestions={20}
        currentQuestion={currentQuestion}
        answers={mockAnswers}
        onQuestionSelect={(index) => {
          console.log('Selected question:', index + 1);
          setCurrentQuestion(index);
        }}
      />
    </div>
  );
}

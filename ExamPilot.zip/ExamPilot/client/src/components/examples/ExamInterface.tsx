import ExamInterface from '../ExamInterface';

export default function ExamInterfaceExample() {
  const mockExam = {
    id: "demo-exam",
    title: "NEET Physics Mock Test 1",
    description: "Comprehensive physics test",
    duration: 45,
    totalQuestions: 5,
    difficulty: "Medium" as const,
    subjects: ["Physics"],
    questions: [
      {
        id: "q1",
        text: "What is the SI unit of force?",
        options: ["Joule", "Newton", "Watt", "Pascal"],
        correctAnswer: 1,
        subject: "Physics"
      },
      {
        id: "q2",
        text: "The acceleration due to gravity on Earth is approximately:",
        options: ["9.8 m/s²", "10.8 m/s²", "8.8 m/s²", "11.8 m/s²"],
        correctAnswer: 0,
        subject: "Physics"
      },
      {
        id: "q3",
        text: "Which law states that for every action, there is an equal and opposite reaction?",
        options: ["First Law of Motion", "Second Law of Motion", "Third Law of Motion", "Law of Gravitation"],
        correctAnswer: 2,
        subject: "Physics"
      }
    ]
  };

  const mockUser = {
    id: "1",
    username: "johndoe",
    email: "john@example.com",
    password: "",
    createdAt: new Date().toISOString()
  };

  return (
    <ExamInterface 
      exam={mockExam}
      user={mockUser}
      onComplete={(answers, time) => console.log('Exam completed:', { answers, time })}
      onExit={() => console.log('Exit exam')}
    />
  );
}

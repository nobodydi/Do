import Login from '../Login';

export default function LoginExample() {
  return (
    <Login 
      onLogin={(user) => console.log('Login successful:', user)}
      onSwitchToSignup={() => console.log('Switch to signup')}
    />
  );
}

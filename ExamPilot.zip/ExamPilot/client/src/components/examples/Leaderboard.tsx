import Leaderboard from '../Leaderboard';

export default function LeaderboardExample() {
  const mockAttempts = [
    {
      id: "1",
      examId: "exam1",
      examTitle: "NEET Physics Mock Test 1",
      userId: "user1",
      username: "Alice Johnson",
      answers: [],
      score: 18,
      totalQuestions: 20,
      timeSpent: 2400,
      completedAt: new Date().toISOString()
    },
    {
      id: "2",
      examId: "exam1",
      examTitle: "NEET Physics Mock Test 1",
      userId: "user2",
      username: "Bob Smith",
      answers: [],
      score: 17,
      totalQuestions: 20,
      timeSpent: 2500,
      completedAt: new Date().toISOString()
    },
    {
      id: "3",
      examId: "exam2",
      examTitle: "NEET Chemistry Mock Test 1",
      userId: "user3",
      username: "Carol Davis",
      answers: [],
      score: 16,
      totalQuestions: 20,
      timeSpent: 2300,
      completedAt: new Date().toISOString()
    },
    {
      id: "4",
      examId: "exam1",
      examTitle: "NEET Physics Mock Test 1",
      userId: "current",
      username: "You",
      answers: [],
      score: 15,
      totalQuestions: 20,
      timeSpent: 2600,
      completedAt: new Date().toISOString()
    }
  ];

  return (
    <Leaderboard 
      attempts={mockAttempts}
      currentUserId="current"
      onBack={() => console.log('Back to dashboard')}
    />
  );
}

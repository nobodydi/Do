import { Exam } from "@shared/schema";

export const mockExams: Exam[] = [
  {
    id: "neet-physics-1",
    title: "NEET Physics Mock Test 1",
    description: "Comprehensive physics test covering mechanics, thermodynamics, and modern physics",
    duration: 45,
    totalQuestions: 20,
    difficulty: "Medium",
    subjects: ["Physics"],
    questions: [
      {
        id: "q1",
        text: "What is the SI unit of force?",
        options: ["Joule", "Newton", "Watt", "Pascal"],
        correctAnswer: 1,
        subject: "Physics"
      },
      {
        id: "q2",
        text: "The acceleration due to gravity on Earth is approximately:",
        options: ["9.8 m/s²", "10.8 m/s²", "8.8 m/s²", "11.8 m/s²"],
        correctAnswer: 0,
        subject: "Physics"
      },
      {
        id: "q3",
        text: "Which law states that for every action, there is an equal and opposite reaction?",
        options: ["First Law of Motion", "Second Law of Motion", "Third Law of Motion", "Law of Gravitation"],
        correctAnswer: 2,
        subject: "Physics"
      },
      {
        id: "q4",
        text: "The unit of electric current is:",
        options: ["Volt", "Ampere", "Ohm", "Coulomb"],
        correctAnswer: 1,
        subject: "Physics"
      },
      {
        id: "q5",
        text: "What is the speed of light in vacuum?",
        options: ["3 × 10⁸ m/s", "3 × 10⁶ m/s", "3 × 10⁷ m/s", "3 × 10⁹ m/s"],
        correctAnswer: 0,
        subject: "Physics"
      }
    ]
  },
  {
    id: "neet-chemistry-1",
    title: "NEET Chemistry Mock Test 1",
    description: "Test your knowledge in organic, inorganic, and physical chemistry",
    duration: 45,
    totalQuestions: 20,
    difficulty: "Medium",
    subjects: ["Chemistry"],
    questions: [
      {
        id: "c1",
        text: "What is the atomic number of Carbon?",
        options: ["4", "6", "8", "12"],
        correctAnswer: 1,
        subject: "Chemistry"
      },
      {
        id: "c2",
        text: "The pH value of pure water is:",
        options: ["5", "6", "7", "8"],
        correctAnswer: 2,
        subject: "Chemistry"
      },
      {
        id: "c3",
        text: "Which gas is known as laughing gas?",
        options: ["NO₂", "N₂O", "NO", "N₂O₃"],
        correctAnswer: 1,
        subject: "Chemistry"
      },
      {
        id: "c4",
        text: "The molecular formula of glucose is:",
        options: ["C₆H₁₂O₆", "C₅H₁₀O₅", "C₆H₁₄O₆", "C₇H₁₄O₇"],
        correctAnswer: 0,
        subject: "Chemistry"
      },
      {
        id: "c5",
        text: "What is the valency of oxygen?",
        options: ["1", "2", "3", "4"],
        correctAnswer: 1,
        subject: "Chemistry"
      }
    ]
  },
  {
    id: "neet-biology-1",
    title: "NEET Biology Mock Test 1",
    description: "Cover essential topics from botany and zoology for NEET preparation",
    duration: 60,
    totalQuestions: 25,
    difficulty: "Hard",
    subjects: ["Biology"],
    questions: [
      {
        id: "b1",
        text: "What is the powerhouse of the cell?",
        options: ["Nucleus", "Ribosome", "Mitochondria", "Chloroplast"],
        correctAnswer: 2,
        subject: "Biology"
      },
      {
        id: "b2",
        text: "The process of photosynthesis occurs in:",
        options: ["Mitochondria", "Chloroplast", "Nucleus", "Ribosome"],
        correctAnswer: 1,
        subject: "Biology"
      },
      {
        id: "b3",
        text: "DNA stands for:",
        options: ["Deoxyribonucleic Acid", "Diribonucleic Acid", "Deoxyribose Acid", "Diribose Nucleic Acid"],
        correctAnswer: 0,
        subject: "Biology"
      },
      {
        id: "b4",
        text: "How many chromosomes are present in human cells?",
        options: ["22", "23", "44", "46"],
        correctAnswer: 3,
        subject: "Biology"
      },
      {
        id: "b5",
        text: "The smallest unit of life is:",
        options: ["Tissue", "Organ", "Cell", "Molecule"],
        correctAnswer: 2,
        subject: "Biology"
      }
    ]
  },
  {
    id: "jee-maths-1",
    title: "JEE Mathematics Mock Test 1",
    description: "Practice advanced mathematics problems for JEE preparation",
    duration: 60,
    totalQuestions: 30,
    difficulty: "Hard",
    subjects: ["Mathematics"],
    questions: [
      {
        id: "m1",
        text: "What is the value of π (pi) approximately?",
        options: ["3.12", "3.14", "3.16", "3.18"],
        correctAnswer: 1,
        subject: "Mathematics"
      },
      {
        id: "m2",
        text: "The derivative of x² is:",
        options: ["x", "2x", "x²", "2x²"],
        correctAnswer: 1,
        subject: "Mathematics"
      },
      {
        id: "m3",
        text: "What is the square root of 144?",
        options: ["10", "11", "12", "13"],
        correctAnswer: 2,
        subject: "Mathematics"
      },
      {
        id: "m4",
        text: "The sum of angles in a triangle is:",
        options: ["90°", "180°", "270°", "360°"],
        correctAnswer: 1,
        subject: "Mathematics"
      },
      {
        id: "m5",
        text: "What is the value of sin(90°)?",
        options: ["0", "0.5", "1", "∞"],
        correctAnswer: 2,
        subject: "Mathematics"
      }
    ]
  },
  {
    id: "general-aptitude-1",
    title: "General Aptitude Test",
    description: "Test your logical reasoning and quantitative aptitude skills",
    duration: 30,
    totalQuestions: 15,
    difficulty: "Easy",
    subjects: ["Aptitude"],
    questions: [
      {
        id: "a1",
        text: "If A is to the north of B and B is to the west of C, then C is in which direction with respect to A?",
        options: ["North-East", "South-East", "South-West", "North-West"],
        correctAnswer: 1,
        subject: "Aptitude"
      },
      {
        id: "a2",
        text: "What comes next in the series: 2, 6, 12, 20, ?",
        options: ["28", "30", "32", "36"],
        correctAnswer: 1,
        subject: "Aptitude"
      },
      {
        id: "a3",
        text: "If 5 workers can complete a job in 12 days, how many days will 10 workers take?",
        options: ["4 days", "6 days", "8 days", "10 days"],
        correctAnswer: 1,
        subject: "Aptitude"
      },
      {
        id: "a4",
        text: "Which number is the odd one out: 2, 4, 6, 9, 10?",
        options: ["2", "4", "9", "10"],
        correctAnswer: 2,
        subject: "Aptitude"
      },
      {
        id: "a5",
        text: "A train 100m long running at 36 km/hr takes how many seconds to cross a pole?",
        options: ["5 seconds", "10 seconds", "15 seconds", "20 seconds"],
        correctAnswer: 1,
        subject: "Aptitude"
      }
    ]
  }
];

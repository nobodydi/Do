import { useState, useEffect } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { User, ExamAttempt, UserAnswer } from "@shared/schema";
import { getCurrentUser, logout as authLogout } from "@/lib/auth";
import { mockExams } from "@/lib/examData";
import Login from "@/components/Login";
import Signup from "@/components/Signup";
import Dashboard from "@/components/Dashboard";
import ExamInterface from "@/components/ExamInterface";
import Results from "@/components/Results";
import Leaderboard from "@/components/Leaderboard";
import Profile from "@/components/Profile";

type View = "login" | "signup" | "dashboard" | "exam" | "results" | "leaderboard" | "profile";

const ATTEMPTS_KEY = "mocktest_attempts";

function App() {
  const [currentView, setCurrentView] = useState<View>("login");
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentExamId, setCurrentExamId] = useState<string | null>(null);
  const [lastAttempt, setLastAttempt] = useState<ExamAttempt | null>(null);
  const [attempts, setAttempts] = useState<ExamAttempt[]>([]);

  useEffect(() => {
    const user = getCurrentUser();
    if (user) {
      setCurrentUser(user);
      setCurrentView("dashboard");
    }

    const savedAttempts = localStorage.getItem(ATTEMPTS_KEY);
    if (savedAttempts) {
      setAttempts(JSON.parse(savedAttempts));
    }
  }, []);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setCurrentView("dashboard");
  };

  const handleSignup = (user: User) => {
    setCurrentUser(user);
    setCurrentView("dashboard");
  };

  const handleLogout = () => {
    authLogout();
    setCurrentUser(null);
    setCurrentView("login");
  };

  const handleStartExam = (examId: string) => {
    setCurrentExamId(examId);
    setCurrentView("exam");
  };

  const handleExamComplete = (answers: UserAnswer[], timeSpent: number) => {
    if (!currentUser || !currentExamId) return;

    const exam = mockExams.find(e => e.id === currentExamId);
    if (!exam) return;

    let score = 0;
    answers.forEach((answer, index) => {
      if (answer.selectedAnswer === exam.questions[index].correctAnswer) {
        score++;
      }
    });

    const attempt: ExamAttempt = {
      id: Date.now().toString(),
      examId: exam.id,
      examTitle: exam.title,
      userId: currentUser.id,
      username: currentUser.username,
      answers,
      score,
      totalQuestions: exam.questions.length,
      timeSpent,
      completedAt: new Date().toISOString(),
    };

    const updatedAttempts = [...attempts, attempt];
    setAttempts(updatedAttempts);
    localStorage.setItem(ATTEMPTS_KEY, JSON.stringify(updatedAttempts));
    
    setLastAttempt(attempt);
    setCurrentView("results");
  };

  const handleExitExam = () => {
    setCurrentExamId(null);
    setCurrentView("dashboard");
  };

  const currentExam = currentExamId ? mockExams.find(e => e.id === currentExamId) : null;

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        {currentView === "login" && (
          <Login
            onLogin={handleLogin}
            onSwitchToSignup={() => setCurrentView("signup")}
          />
        )}

        {currentView === "signup" && (
          <Signup
            onSignup={handleSignup}
            onSwitchToLogin={() => setCurrentView("login")}
          />
        )}

        {currentView === "dashboard" && currentUser && (
          <Dashboard
            user={currentUser}
            onLogout={handleLogout}
            onStartExam={handleStartExam}
            onViewProfile={() => setCurrentView("profile")}
            onViewLeaderboard={() => setCurrentView("leaderboard")}
          />
        )}

        {currentView === "exam" && currentUser && currentExam && (
          <ExamInterface
            exam={currentExam}
            user={currentUser}
            onComplete={handleExamComplete}
            onExit={handleExitExam}
          />
        )}

        {currentView === "results" && currentUser && currentExam && lastAttempt && (
          <Results
            exam={currentExam}
            answers={lastAttempt.answers}
            score={lastAttempt.score}
            timeSpent={lastAttempt.timeSpent}
            onBackToDashboard={() => setCurrentView("dashboard")}
            onViewLeaderboard={() => setCurrentView("leaderboard")}
          />
        )}

        {currentView === "leaderboard" && currentUser && (
          <Leaderboard
            attempts={attempts}
            currentUserId={currentUser.id}
            onBack={() => setCurrentView("dashboard")}
          />
        )}

        {currentView === "profile" && currentUser && (
          <Profile
            user={currentUser}
            attempts={attempts}
            onBack={() => setCurrentView("dashboard")}
          />
        )}

        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

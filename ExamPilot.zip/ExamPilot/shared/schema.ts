import { z } from "zod";

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number;
  subject?: string;
}

export interface Exam {
  id: string;
  title: string;
  description: string;
  duration: number;
  totalQuestions: number;
  difficulty: "Easy" | "Medium" | "Hard";
  subjects: string[];
  questions: Question[];
}

export interface UserAnswer {
  questionId: string;
  selectedAnswer: number | null;
}

export interface ExamAttempt {
  id: string;
  examId: string;
  examTitle: string;
  userId: string;
  username: string;
  answers: UserAnswer[];
  score: number;
  totalQuestions: number;
  timeSpent: number;
  completedAt: string;
}

export interface User {
  id: string;
  username: string;
  email: string;
  password: string;
  createdAt: string;
}

export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const signupSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export type LoginForm = z.infer<typeof loginSchema>;
export type SignupForm = z.infer<typeof signupSchema>;

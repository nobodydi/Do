# Design Guidelines: Online Testing Platform

## Design Approach
**Reference-Based Approach**: Educational platforms like Khan Academy and Byju's - clean, distraction-free exam environments that prioritize focus and clarity during testing sessions.

## Color Palette

### Light Mode (Primary)
- **Primary**: #2563EB (professional blue) - buttons, links, active states
- **Secondary**: #059669 (success green) - correct answers, success messages
- **Background**: #F8FAFC (clean white) - main background
- **Cards**: #FFFFFF (pure white) - exam cards, question containers
- **Text**: #1E293B (dark slate) - primary text
- **Accent**: #DC2626 (alert red) - timer warnings, incorrect answers, alerts

## Typography
- **Font Families**: Inter for UI elements, Poppins for headings
- **Hierarchy**: 
  - Page titles: Poppins 32px/bold
  - Section headers: Poppins 24px/semibold
  - Body text: Inter 16px/regular
  - Buttons/labels: Inter 14px/medium

## Layout System
- **Spacing**: Tailwind units of 4, 6, and 8 (p-4, m-6, gap-8) for consistent rhythm
- **Cards**: White background, subtle shadow, 12px border radius
- **Grid**: Responsive grid for exam cards (1 column mobile, 2-3 columns desktop)
- **Single-page navigation**: Clean tab/section switching without page reloads

## Component Library

### Authentication Pages
- Centered card-based forms with clean inputs
- Minimal distractions, focus on form completion
- Clear error states in red, success in green

### Dashboard
- Grid of exam cards displaying: exam name, duration, question count, difficulty, start button
- Each card: white background, hover elevation effect, primary blue CTA button
- Clean header with user profile indicator and logout option

### Exam Interface
- **Timer**: Prominently displayed at top-right, changes to red when <5 minutes remain
- **Question display**: Large, clear text with numbered questions
- **MCQ options**: Radio buttons with hover states, clear selection indicators
- **Navigation**: Question palette showing attempted/unattempted status with color coding
- **Submit button**: Green, sticky footer position

### Results Display
- **Score card**: Large, centered display with percentage and grade
- **Answer review**: Question-by-question breakdown with correct/incorrect indicators
- **Performance metrics**: Time taken, accuracy percentage, subject-wise breakdown

### Profile & Leaderboard
- **History**: Table/card view of past exams with scores and dates
- **Leaderboard**: Ranked list with user highlighting, top 3 prominently displayed

## Images
No hero images required - this is a utility-focused educational platform prioritizing functionality over marketing aesthetics. The clean, minimal interface keeps students focused on exam content.

## Animations
Minimal and purposeful only:
- Smooth transitions for card hovers (200ms)
- Timer pulse effect when critical (<5 min)
- Success/error message fade-ins
- No distracting animations during exams

## Key Design Principles
1. **Distraction-free**: Clean interfaces during exams with no unnecessary visual elements
2. **Clear feedback**: Immediate visual confirmation for actions (selections, submissions)
3. **Accessibility**: High contrast ratios, large touch targets (min 44px), keyboard navigation
4. **Responsive**: Mobile-first approach, readable on all devices
5. **Performance**: Fast loading, instant feedback, no janky interactions